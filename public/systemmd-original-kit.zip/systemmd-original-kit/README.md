# SystemMD Original Blueprint Kit

The hand-crafted blueprint that started SystemMD.

## Files
- .cursorrules — AI coding rules for Cursor/Windsurf
- schema.sql — Supabase database schema
- BUILD.md — Full build guide
- .env.example — Environment variables

## Quick Start
npx create-next-app@latest my-app --typescript --tailwind --eslint --app --src-dir
cd my-app
# Run schema.sql in Supabase SQL Editor
# Copy .env.example to .env.local

---
systemmd.com