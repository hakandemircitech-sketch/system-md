# SystemMD Original Blueprint Kit
# The file that started it all.
# systemmd.com

## WHAT THIS IS
A hand-crafted blueprint for building a production SaaS.
Before the AI generator, this was done by hand.

## STACK
- Frontend: Next.js 14 + TypeScript + Tailwind CSS
- Backend: Next.js API Routes
- Database: Supabase (PostgreSQL + RLS)
- Auth: Supabase Auth
- Payments: Stripe
- Email: Resend
- Hosting: Vercel

## BUILD GUIDE
1. Clone repo and install dependencies
2. Create Supabase project, run schema.sql
3. Copy .env.example to .env.local, fill all values
4. Run npm run dev
5. Deploy to Vercel

## THIS WEEK
1. Set up Supabase project and run schema
2. Implement auth flow (signup, login, callback)
3. Build dashboard layout with sidebar
4. Create first core feature
5. Add Stripe checkout for first paid plan