-- SystemMD Original Blueprint Kit
-- Database Schema

create table users (
  id uuid primary key references auth.users,
  email text not null,
  plan text default 'free',
  created_at timestamptz default now()
);

create table projects (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references users(id) on delete cascade,
  name text not null,
  status text default 'active',
  created_at timestamptz default now()
);

alter table users enable row level security;
alter table projects enable row level security;

create policy "users_own" on users for all using (auth.uid() = id);
create policy "projects_own" on projects for all using (auth.uid() = user_id);